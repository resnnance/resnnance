### ReSNNance

An FPGA hardware accelerator generator for spiking neural networks + PyNN frontend
