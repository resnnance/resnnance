from pyNN.standardmodels import StandardCellType

class IF_hybrid_exp(StandardCellType):
    pass
